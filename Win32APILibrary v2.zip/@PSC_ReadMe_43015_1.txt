Title: Win32APILibrary v2.0
Description: Totally rewritten the library and added new functionality, including network drive mapping and SMTP email (still working on this as i can't get it to work 100% of the time). Please vote for this code as it gives me the encouragment to improve it and to add new features.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43015&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

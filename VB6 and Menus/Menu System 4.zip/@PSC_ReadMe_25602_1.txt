Title: Menu System 4.1
Description: This class allows you to replace the standard Visual Basic menu with one that supports many more features, some of which include:
Addition of bitmaps or icons to menu items (supports any size). 
Optional MonoDefault state will only colorize icons of menu items that are selected (a la Outlook Express) 
Extended keyboard shortcut keys, using Ctrl+, Shift+, Ctrl+Shift+, combinations, function keys, system keys, the menu and print keys, and the CapsLock key. 
Draws in the style of the Office 97 menu bar. 
Implements Visual Studio-menu style check marks and radio buttons. 
Implements Hot-tracking, Hot-lighted and Clear-box highlighting visual effects. 
Implements a "CaptionSeperator" item-type which is a Seperator Bar with scaled, centered text and optional background coloring and submenu support. 
Implements Color-select, a type of highlighting that lets the highlight bar be different than the system default 
Background gradients 
Multi-line menu items 
DBCS (Unicode) support for languages such as Chinese 
Each feature is Item-by-item. You can have a whole menu full of items that colorize or highlight differently.
Version Upgrades: 4.1 (07/01/2001), 4.0 (06/18/01), 3.0 (02/22/2001) and 2.3 (10/28/2000): New Features include: Each item may have its own Font, right-justification of menu items, and support for menu breaks and menu bar-breaks. In Version 4.0, the object model was completely revamped and simplified, developer documentation is now included, and a number of new features, such as support for background gradients, multi-line menu items, and Unicode, were added. Version 4.1 adds Office XP style flat menus.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25602&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

*****  Written by Paul Cormie   *****
*****  November 2000   *****


-----------------------------------------
--  please note this is not an exe that 
--  links to another exe, it is part of 
--  an application written in VB6.  If you 
--  try the exe after unzipping it, it 
--  obviously will not work because you 
--  havent set the location of the ini 
--  file (text.ini).  There are instructions
--  on how to do this in the code.
-----------------------------------------
This code (with comments all though it)requires an 
external ini file.  This fileholds the encrypted 
password.  The first login screen has a button that 
shows what the encrypted password in the text.ini 
file is (initially set to "password")

The next screen, "your application is pretty self 
explanitory.  This code is added on to an existing 
application, with the menu on "your application".

The change password screen has some message boxes 
that pop up if any errors occur in changing the password.

Remember, read all the comments in the code BEFORE 
you say it doesnt work. I hope i have helped with 
any question you might have had.  Enjoy the VB code.


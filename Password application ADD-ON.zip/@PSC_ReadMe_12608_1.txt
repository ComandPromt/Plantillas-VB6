Title: a Password application ADD-ON - with option to change encrypted password in an ini file
Description: I looked here and couldnt find what i was looking for, so i made it and am making it availible to everyone!
allows simple encryption to an external *.ini file (you choose location) as well, there is another dialog box that allows the user to change the password to whatever. READ THE READ_ME_.txt before running the password.exe. the password.exe is just to give you a quick view of the program. You have to go into the code and change a few of the settings.--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------  all the code is commented for easy customization, and i hope you enjoy it! ---->If you like the "app add-on" then please vote for me <-----
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=12608&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

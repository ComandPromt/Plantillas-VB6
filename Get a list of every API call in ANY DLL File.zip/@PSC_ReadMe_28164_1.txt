Title: Get a list of every API call in ANY DLL File
Description: This code can be useful if you want to use more of the API calls located in Different DLL Libraries. Don't forget to vote!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=28164&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

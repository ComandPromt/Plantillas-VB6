Title: EXE/DLL/OCX/OCA/TLB Type-library decompiler
Description: This program will decompile/read and interpret ANY type library. A type library is a library in some DLL's, EXE's and all OCX,OCA and TLB files. It contains information like function, parameters, descriptions, events, subroutines, properties, GUID ext.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13892&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

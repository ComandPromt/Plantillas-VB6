This zipped file is associated with Andy Dean's article, "Integrate VB Apps With the Windows Shell" [Getting Started with Visual Basic Winter 1998/1999]. 

Listings.txt: the code listings printed in the magazine
A sample class module you can use to create file associations

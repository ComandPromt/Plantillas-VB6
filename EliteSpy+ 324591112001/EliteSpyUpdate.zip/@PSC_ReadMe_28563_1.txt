Title: EliteSpy+ (with Code Generator)
Description: EliteSpy+ is program for spying windows. You can spy any window and you can manipulate them using the command buttons in Program. You can minimize, maximize, terminate, enable, disable, flash, put on top, etc.
This program also contains a code generator which you can use to generate code which will manipulate with the specified window.
There is also a list of running process. You can also terminate any process you want.
And please vote for this program if you like it!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=28563&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

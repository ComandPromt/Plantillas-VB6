Title: INI Expert - Manipulate INIFiles like never before
Description: This code can literally do anything you wish with an INI file. Here are a list of the 21 INI functions that I created. These took me a long time to make, so please let me know what you think. A program is included that explains everything completely...from how to use the functions...to an explanation of each variable.
GetKeyVal(), AddToINI(), DeleteSection(), DeleteKey(), DeleteKeyValue(), TotalSections(), TotalKeys(), NumKeys()-"To count how many keys in 1 section"-RenameSection(), RenameKey(), GetKey(), GetKey2(), GetSection(), IsKey(), IsSection(), KeyExists(), KeyExists2(), SectionExists(), GetSectionIndex(), GetKeyIndex(), GetKeyIndex2().
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5756&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

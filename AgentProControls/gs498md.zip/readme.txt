This zip file includes the full listings for John Moody's article, "Create an Animated Desktop Assistant" [Getting Started with Visual Basic, Winter 1998/1999].

It also includes the full source, including a working version of the AgentPro control.


Title: BAS Files Collection, various functions
Description: Loads of .BAS files that make lots of things easier to do such as:
Read/Write Registry,
Use System Tray Icon,
Play MP3s and Wave files,
+ lots lots more!
If you need any help using these mail me.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=26577&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

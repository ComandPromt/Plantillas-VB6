This file contains listings and code associated with "Ask the VB Pro" in Getting Started
with Visual Basic, Winter 1998.

It contains the COpSysInfo.cls  and two additional files (OpSys.vbp and FOpSys.frm)
that together make up a project to exercise the class.  Also, a compiled (/w VB5-SP3)
demo is included for quick testing.

----------------------------------------------------------------
RoboPrint README.TXT
----------------------------------------------------------------
RoboPrint is the only Control that provides fully and  automatic 
Preview and Print, RoboPrint5 for Visual Basic 5.0 and RoboPrint6 for Visual Basic 6.0 
Applications, code is not needed. 
The following controls are printed by RoboPrint:       
DBGrid - DataGrid - MsFlexGrid - MSHFlexGrid - vsFlexGrid - 
TextBox - Label - MaskEdBox - ComboBox.Text - ListBox - 
ListView - Shape - Line - CheckBox - OptionButton - MSChart - 
Pictures of PictureBox and Image.     
RoboPrint prints the entire contents of the Expanding Controls: 
DBGrid, DataGrid, MSFlexGrid, MSHFlexGrid, vsFlexGrid, 
ListView  and Multiline TextBox, in Multipages feature if needed. 
Roboprint is a Shareware Ocx

ROBOCX COMPANY 
                          Hatishbi 13  
                          Kiryat Tivon  
                          Zip 36000  
                          Israel  
                          http://robocx.com
                          Contact: admin@robocx.com
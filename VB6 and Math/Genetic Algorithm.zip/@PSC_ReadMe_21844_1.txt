Title: A Genetic Algorithm with a Twist
Description: The purpose of this code is to demonstrate that a Genetic algorithm can be created using real values, that is by using real numbers instead of binary representations of them.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=21844&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
